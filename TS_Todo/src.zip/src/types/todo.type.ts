export interface TodoInterface {
  id: number;
  text: string;
  completed: boolean;
}
